# Protótipo de Análise Infantil com IA

Este projeto utiliza a API da OpenAI para gerar análises de comportamento infantil com base em descrições fornecidas por profissionais da educação.

## Como rodar localmente

1. Instale as dependências:
